
import javax.swing.JOptionPane;

public class aula6ex2 {

    public static void main(String[] args) {
        float val , valor, menor = 0, vall = 0;
        int valpos = 0, valneg = 0;
        
        val = Float.parseFloat(
                JOptionPane.showInputDialog(null, "Digite a quantidade de valores que serão processados", "Espaço",
                        JOptionPane.INFORMATION_MESSAGE));
        for (int x = 0;x < val; x++){
            valor = Float.parseFloat(
                JOptionPane.showInputDialog(null, "Digite um valor", "Valor",
                        JOptionPane.INFORMATION_MESSAGE)); 
            vall = valor;
            if(menor > vall){
                menor = vall;
            }
            if (valor >= 0){
                valpos++;
            }
            else{
                if (valor < 0){
                    valneg++;
                }
            } 
        } 
        JOptionPane.showMessageDialog(null, "Quantidade de valores positivos são " + valpos,"Valores Positivos",
                        JOptionPane.INFORMATION_MESSAGE);
        JOptionPane.showMessageDialog(null, "Quantidade de valores negativos são " + valneg,"Valores Positivos",
                        JOptionPane.INFORMATION_MESSAGE);
        JOptionPane.showMessageDialog(null, "O menor valor é o " + menor,"Valores Positivos",
                        JOptionPane.INFORMATION_MESSAGE);
    }
}

