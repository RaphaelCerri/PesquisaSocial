
import javax.swing.JOptionPane;

public class aula6ex1 {

    public static void main(String[] args) {
        float val ,contador = 0, per, result, s = 0;
        val = Float.parseFloat(
                JOptionPane.showInputDialog(null, "Digite a quantidade de valores que serão processados", "Espaço",
                        JOptionPane.INFORMATION_MESSAGE));
        for (int x = 0;x < val; x++){
            per = Float.parseFloat(
                JOptionPane.showInputDialog(null, "Digite um valor", "Valor",
                        JOptionPane.INFORMATION_MESSAGE));
            s = s + per;      
        }
        result = s/val;
        JOptionPane.showMessageDialog(null, "A média dos valores digitados é " + result,"Média",
                        JOptionPane.INFORMATION_MESSAGE);
    }
}

